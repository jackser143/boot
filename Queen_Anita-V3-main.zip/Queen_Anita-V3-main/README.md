## Queen_Anita-V3
   <a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<p align="center"> 
<u>⚡ A simple WhatsApp User Bot Created David Cyril ⚡</u>
</p>
<p align="center">
<img src="https://api.shannmoderz.xyz/server/file/JhnZNPg59LpUxYf.jpg"/>       
<p align="center">
  <a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=EB+Garamond&weight=800&size=28&duration=4000&pause=1000&random=false&width=435&lines=+•★⃝ QUEEN-+ANITA-+V3★⃝•;MULTI-DEVICE+WHATSAPP+BOT;DEVELOPED+BY+DAVID+CYRIL;RELEASED+DATE+22%2F8%2F2024." alt="Typing SVG" /></a>
 </p>
<p align="center">
<a href="#"><img title="Creator" src="https://img.shields.io/badge/Creator-DAVID_CYRIL-red.svg?style=for-the-badge&logo=github"></a>
</p>
<p align="center">
<a href="https://github.com/DeeCeeXxx/Queen_Anita-V3/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/DeeCeeXxx/Queen_Anita-V3?color=blue&style=flat-square"></a>
<a href="https://github.com/DeeCeeXxx/Queen_Anita-V3/network/members"><img title="Forks" src="https://img.shields.io/github/forks/DeeCeeXxx/Queen_Anita-V3?color=yellow&style=flat-square"></a>
<a href="https://github.com/DeeCeeXxx/Queen_Anita-V3/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/DeeCeeXxx/Queen_Anita-V3?label=Watchers&color=red&style=flat-square"></a>
<a href="https://github.com/DeeCeeXxx/Queen_Anita-V3/graphs/commit-activity"><img height="20" src="https://img.shields.io/badge/Maintained-Yes-red.svg"></a>&nbsp;&nbsp;
</p>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
#

## Queen_Anita-V3 Deployment Methods
---
1.  **Fork Repo First, [`CLICK HERE`](https://github.com/DeeCeeXxx/Queen_Anita-V3/fork) (A MUST) and `Star ⭐ Repository` for Courage.**
2.  **Get `SESSION ID` ON [`REPLIT`](https://replit.com/@deeceexxx01/DavidCyril-X-pair-1)** 

3. **UPLOAD YOUR CREDS.JSON FILE ON SESSION FOLDER**

4. **Deploy on [`SCALINGO`](https://dashboard.scalingo.com)**

5. **Deploy on [`HEROKU`](https://dashboard.heroku.com/new?template*=https://github.com/DeeCeeXxx/Queen_Anita-V3)** 

6. **Deploy on [`REPLIT`](https://replit.com/github/Deeceexxx/Queen_Anita-V2)** 

7. **Deploy on [`RAILWAY`](https://railway.com/github/Deeceexxx/Queen_Anita-V2)**  

8. **You can visit Bot whatsapp channel [`BY CLICKING HERE`](https://whatsapp.com/channel/0029VaeRru3ADTOEKPCPom0L) for more**

9. **All Tutorials Here [`Click Here`](https://www.youtube.com/@DavidCyril_TECH)**

</a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

## ```Connect With Me```<img src="https://github.com/0xAbdulKhalid/0xAbdulKhalid/raw/main/assets/mdImages/handshake.gif" width ="80"></h1> 
 <br> 
<p align="center">
<a href="https://wa.me/2349066528353"><img src="https://img.shields.io/badge/Contact David-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
<a href="https://whatsapp.com/channel/0029VaeRru3ADTOEKPCPom0L"><img src="https://img.shields.io/badge/Join Official Channel-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
<a href="https://t.me/deecee_x"><img src="https://img.shields.io/badge/Telegram-0088cc?style=for-the-badge&logo=telegram&logoColor=white" /><br>
<p align="center">
<img alt="Development" width="250" src="https://media2.giphy.com/media/W9tBvzTXkQopi/giphy.gif?cid=6c09b952xu6syi1fyqfyc04wcfk0qvqe8fd7sop136zxfjyn&ep=v1_internal_gif_by_id&rid=giphy.gif&ct=g" /> </p>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
# 

<br>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

* [🧑‍💻 Follow Queen_Anita-V3 Whatsapp Channel🧑‍💻](https://whatsapp.com/channel/0029VaeRru3ADTOEKPCPom0L)

* [🧑‍💻 Join Queen_Anita-V3 Telegram Group 🧑‍💻](https://t.me/dctech)

* [✅ Join Public Group ⚡](https://chat.whatsapp.com/KLu7a2r4bc4JFV8s5epvsF)

  <a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
  

- *Queen_Anita-V3 is not made by `WhatsApp Inc.` Sometimes or misusing the bot might `ban` your `WhatsApp account!`*
- *In that case, I'm not responsible for banning your account.*
- *Use Queen_Anita-V3 at your own risk by keeping this warning in mind.*
  
  #### ```DAVID CYRIL PROFILE VIEWS 🧚```
![Visitor Count](https://profile-counter.glitch.me/DeeCeeXxx/count.svg)

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

## Community and Support

FOLLOW DAVID CYRIL WHAtSAPP CHANNEL FOR MORE UPDATES
[![JOIN WHATSAPP GROUP](https://raw.githubusercontent.com/Neeraj-x0/Neeraj-x0/main/photos/suddidina-join-whatsapp.png)](https://whatsapp.com/channel/0029VaeRru3ADTOEKPCPom0L))
